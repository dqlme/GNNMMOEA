import numpy as np
import torch
from pop_class import *

def findominatImdex(pop,n_var,n_obj):  #该函数用于生成支配关系的邻接矩阵，a[i][j]=1表明第i个个体支配第j个个体
    N_particle = pop.shape[0]  # Obtain the number of particles
    DR=np.zeros((N_particle,N_particle))
    for i in range(N_particle):
        for j in range(N_particle):
            dom_less = 0
            dom_equal = 0
            dom_more = 0
            for k in range (n_obj):
                if (pop[i,n_var + k] < pop[j,n_var + k]):
                    dom_less = dom_less + 1
                elif (pop[i,n_var + k] == pop[j,n_var + k]):  
                    dom_equal = dom_equal + 1
                else:
                    dom_more = dom_more + 1
            if (dom_more == 0 and dom_equal != n_obj):
                DR[i,j]=1  
                #DR[j,i]=-1 
    return DR    

def setdiff2d(array1,array2): #求两个元素的差集
    set1 = set(map(tuple, array1))
    set2 = set(map(tuple, array2))

    # 找到在第一个集合中但不在第二个集合中的元素
    result_set = set1 - set2

    # 转换回数组形式
    result_array = np.array(list(result_set))
    return result_array
class GraphData:
    def __init__(self,Gpop,Bpop):  #Apop代表当前种群中的所有解，Gpop代表种群中的好解，Bpop代表当前种群中的差解
        self.n_var=Gpop.decs.shape[1]
        self.n_obj=Gpop.objs.shape[1]
        self.Gpop=np.concatenate((Gpop.decs, Gpop.objs), axis=1)
        self.Bpop=np.concatenate((Bpop.decs, Bpop.objs), axis=1)
        # print("self.Gpop",self.Gpop.shape)
        # print("self.Bpop",self.Bpop.shape)
        self.GgroundTruth=np.concatenate((np.ones((self.Gpop.shape[0],1)), np.zeros((self.Gpop.shape[0],1))), axis=1) #GroundTruth矩阵第一列为1，第二行全部为0表示全部是好解
        self.BgroundTruth=np.concatenate((np.zeros((self.Bpop.shape[0],1)), np.ones((self.Bpop.shape[0],1))), axis=1)
        tempG=np.concatenate((self.Gpop, self.GgroundTruth), axis=1)
        tempB=np.concatenate((self.Bpop, self.BgroundTruth), axis=1)
        # print("tempG",tempG.shape)
        # print("tempB",tempB.shape)
        self.Tpop=np.concatenate((tempG, tempB), axis=0) #结点的矩阵
        #print("self.Tpop",self.Tpop.shape)
        np.random.shuffle(self.Tpop) #随机交换各行
        self.GroundTruth=self.Tpop[:, -2:]
        self.Tpop=self.Tpop[:,0:self.n_var+self.n_obj]
        # print("self.Tpop",self.Tpop.shape)
        self.DR=findominatImdex(self.Tpop,self.n_var,self.n_obj) #支配关系的邻接矩阵
    def saveTrainData(self,train_i):
        file_name='./Data/TrainData/node_{}.npy'.format(train_i)
        np.save(file_name, self.Tpop)
        file_name='./Data/TrainData/GroundTruth_{}.npy'.format(train_i)
        np.save(file_name, self.GroundTruth)
        file_name='./Data/TrainData/DR_{}.npy'.format(train_i)
        np.save(file_name, self.DR)
    def saveTestData(self):
        file_name='./Data/TestData/node.npy'
        np.save(file_name, self.Tpop)
        file_name='./Data/TestData/GroundTruth.npy'
        np.save(file_name, self.GroundTruth)
        file_name='./Data/TestData/DR.npy'
        np.save(file_name, self.DR)
