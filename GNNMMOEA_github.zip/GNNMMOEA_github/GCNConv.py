import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from torch_geometric.nn import GCNConv
from torch_geometric.data import Data
import numpy as np
from pop_class import *

# class GenderPredictionModel(nn.Module):
#     def __init__(self, input_dim, hidden_dim, output_dim):
#         super(GenderPredictionModel, self).__init__()
#         self.conv1 = GCNConv(input_dim, hidden_dim)
#         self.conv2 = GCNConv(hidden_dim, output_dim)

#     def forward(self, x, edge_index):
#         x = self.conv1(x, edge_index)
#         x = torch.relu(x)
#         x = self.conv2(x, edge_index)

#         return x
class GraphConvolution(nn.Module):
    def __init__(self, in_features, out_features):
        super(GraphConvolution, self).__init__()
        self.weight = nn.Parameter(torch.FloatTensor(in_features, out_features))
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.xavier_uniform_(self.weight)
    def forward(self, x, adj):
        # input: 节点特征矩阵
        # adj: 归一化邻接矩阵
        x=x.to(torch.float32)
        adj=adj.to(torch.float32)
        support = torch.mm(x, self.weight)  # 线性变换
        output = torch.mm(adj, support)  # 邻居信息聚合
        return output
class GCN(nn.Module):
    def __init__(self, nfeat, nhid, nclass):
        super(GCN, self).__init__()
        self.gc1 = GraphConvolution(nfeat, nhid)
        self.gc2 = GraphConvolution(nhid, nhid*2)
        self.gc3 = GraphConvolution(nhid*2, nhid)
        self.gc4 = GraphConvolution(nhid, nclass)

    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))  # 第一层图卷积
        res_x=x
        x = F.relu(self.gc2(x, adj)) 
        x = F.relu(self.gc3(x, adj))
        x=res_x+x
        x = self.gc4(x, adj)  # 第二层图卷积
        return F.softmax(x, dim=1)#F.log_softmax(x, dim=1) 

def findominatImdex(pop,n_var,n_obj):  #该函数用于生成支配关系的邻接矩阵，a[i][j]=1表明第i个个体支配第j个个体
    N_particle = pop.shape[0]  # Obtain the number of particles
    DR=np.zeros((N_particle,N_particle))
    for i in range(N_particle):
        for j in range(N_particle):
            dom_less = 0
            dom_equal = 0
            dom_more = 0
            for k in range (n_obj):
                if (pop[i,n_var + k] < pop[j,n_var + k]):
                    dom_less = dom_less + 1
                elif (pop[i,n_var + k] == pop[j,n_var + k]):  
                    dom_equal = dom_equal + 1
                else:
                    dom_more = dom_more + 1
            if (dom_more == 0 and dom_equal != n_obj):
                DR[i,j]=1  
                DR[j,i]=-1 
    return DR  

class GCN_user(object):
    def __init__(self, lr, epoches, n_var, n_obj, fname, populationsize):
        self.lr=lr
        self.epoches=epoches
        self.n_var=n_var
        self.n_obj=n_obj
        self.fname=fname
        self.model = GCN(nfeat=n_var+n_obj, nhid=8, nclass=2)
        self.criterion = nn.CrossEntropyLoss()
        self.optimizer = optim.Adam(self.model.parameters(), lr=lr)
        self.populationsize=populationsize
    def train(self,trainData):
        self.model.train()
        for epoch in range(self.epoches):
            total_loss = 0.
            for j in range(len(trainData)-1,len(trainData)):
                node=torch.from_numpy(trainData[j].Tpop)
                GroundTruth=torch.from_numpy(trainData[j].GroundTruth)
                DR=torch.from_numpy(trainData[j].DR)

                self.optimizer.zero_grad()
                output = self.model(node, DR)
                #print("output",output)
                loss = self.criterion(output, GroundTruth)
                #print("loss",loss)
                total_loss += loss.item()
                loss.backward()
                self.optimizer.step()
            if epoch % 10 == 0:
                print("Epoch [{}/100], Loss: {:.4f}".format(epoch+1, total_loss/(j+1)))

    def discrimination(self,pop):
        self.model.eval()
        node=np.concatenate((pop.decs, pop.objs), axis=1)
        DR=findominatImdex(node,self.n_var,self.n_obj)
        with torch.no_grad():
            output = self.model(torch.from_numpy(node), torch.from_numpy(DR))

        first_column = output[:, 0]
        # 按照第一列的数字从大到小排序，返回排序后的索引
        sorted_indices = torch.argsort(first_column, descending=True)

        selected_pop=node[sorted_indices]
        selected_pop=pop_class(selected_pop[0:self.populationsize,0:self.n_var],selected_pop[0:self.populationsize,self.n_var:self.n_var+self.n_obj])
        return selected_pop






